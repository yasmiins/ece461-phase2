System.config({
  paths: {
    react: '../../../../build/oss-experimental/react/umd/react.development.js',
    'react-dom':
      '../../../../build/oss-experimental/react-dom/umd/react-dom.development.js',
    schedule:
      '../../../../build/oss-experimental/scheduler/umd/schedule.development',
  },
});
